import sys
from PyQt6 import QtCore, QtGui, QtWidgets
from PyQt6.QtWidgets import QApplication, QMainWindow

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(472, 507)
        self.centralwidget = QtWidgets.QWidget(parent=MainWindow)
        self.centralwidget.setObjectName("centralwidget")

        # Название
        self.label = QtWidgets.QLabel(parent=self.centralwidget)
        self.label.setGeometry(QtCore.QRect(20, 30, 61, 16))
        self.label.setObjectName("label")
        self.name_plainTextEdit = QtWidgets.QPlainTextEdit(parent=self.centralwidget)
        self.name_plainTextEdit.setGeometry(QtCore.QRect(220, 20, 141, 31))
        self.name_plainTextEdit.setObjectName("name_plainTextEdit")

        # Степень прожарки
        self.label_2 = QtWidgets.QLabel(parent=self.centralwidget)
        self.label_2.setGeometry(QtCore.QRect(20, 70, 121, 16))
        self.label_2.setObjectName("label_2")
        self.roast_level_plainTextEdit = QtWidgets.QPlainTextEdit(parent=self.centralwidget)
        self.roast_level_plainTextEdit.setGeometry(QtCore.QRect(220, 60, 141, 31))
        self.roast_level_plainTextEdit.setObjectName("roast_level_plainTextEdit")

        # Тип кофе
        self.label_3 = QtWidgets.QLabel(parent=self.centralwidget)
        self.label_3.setGeometry(QtCore.QRect(20, 120, 71, 16))
        self.label_3.setObjectName("label_3")
        self.coffee_type_comboBox = QtWidgets.QComboBox(parent=self.centralwidget)
        self.coffee_type_comboBox.setGeometry(QtCore.QRect(220, 110, 141, 31))
        self.coffee_type_comboBox.setObjectName("coffee_type_comboBox")
        self.coffee_type_comboBox.addItems(["Молотый", "Зерновой"])  # Added items

        # Цена
        self.label_4 = QtWidgets.QLabel(parent=self.centralwidget)
        self.label_4.setGeometry(QtCore.QRect(20, 170, 55, 16))
        self.label_4.setObjectName("label_4")
        self.price_plainTextEdit = QtWidgets.QPlainTextEdit(parent=self.centralwidget)
        self.price_plainTextEdit.setGeometry(QtCore.QRect(220, 160, 141, 31))
        self.price_plainTextEdit.setObjectName("price_plainTextEdit")

        # Объем
        self.label_5 = QtWidgets.QLabel(parent=self.centralwidget)
        self.label_5.setGeometry(QtCore.QRect(20, 210, 55, 16))
        self.label_5.setObjectName("label_5")
        self.volume_plainTextEdit = QtWidgets.QPlainTextEdit(parent=self.centralwidget)
        self.volume_plainTextEdit.setGeometry(QtCore.QRect(220, 200, 141, 31))
        self.volume_plainTextEdit.setObjectName("volume_plainTextEdit")

        # Описание
        self.label_6 = QtWidgets.QLabel(parent=self.centralwidget)
        self.label_6.setGeometry(QtCore.QRect(20, 250, 61, 16))
        self.label_6.setObjectName("label_6")
        self.description_plainTextEdit = QtWidgets.QPlainTextEdit(parent=self.centralwidget)
        self.description_plainTextEdit.setGeometry(QtCore.QRect(20, 280, 431, 131))
        self.description_plainTextEdit.setObjectName("description_plainTextEdit")

        # Кнопка
        self.pushButton = QtWidgets.QPushButton(parent=self.centralwidget)
        self.pushButton.setGeometry(QtCore.QRect(190, 420, 93, 28))
        self.pushButton.setObjectName("pushButton")

        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(parent=MainWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 472, 26))
        self.menubar.setObjectName("menubar")
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(parent=MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

        # Set object names for widgets
        self.label.setObjectName("label")
        self.label_2.setObjectName("label_2")
        self.label_3.setObjectName("label_3")
        self.label_4.setObjectName("label_4")
        self.label_5.setObjectName("label_5")
        self.label_6.setObjectName("label_6")
        self.name_plainTextEdit.setObjectName("name_plainTextEdit")
        self.roast_level_plainTextEdit.setObjectName("roast_level_plainTextEdit")
        self.coffee_type_comboBox.setObjectName("coffee_type_comboBox")
        self.price_plainTextEdit.setObjectName("price_plainTextEdit")
        self.volume_plainTextEdit.setObjectName("volume_plainTextEdit")
        self.description_plainTextEdit.setObjectName("description_plainTextEdit")
        self.pushButton.setObjectName("pushButton")

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
        self.label.setText(_translate("MainWindow", "Название"))
        self.label_2.setText(_translate("MainWindow", "Степень прожарки"))
        self.label_3.setText(_translate("MainWindow", "Тип кофе"))
        self.label_4.setText(_translate("MainWindow", "Цена"))
        self.label_5.setText(_translate("MainWindow", "Объём"))
        self.label_6.setText(_translate("MainWindow", "Описание"))
        self.pushButton.setText(_translate("MainWindow", "Сохранить"))

class MyMainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)

        # Подключение кнопки (пример)
        self.ui.pushButton.clicked.connect(self.save_data)

    def save_data(self):
        # Здесь будет код для сохранения данных
        name = self.ui.name_plainTextEdit.toPlainText()
        roast_level = self.ui.roast_level_plainTextEdit.toPlainText()
        coffee_type = self.ui.coffee_type_comboBox.currentText()
        price = self.ui.price_plainTextEdit.toPlainText()
        volume = self.ui.volume_plainTextEdit.toPlainText()
        description = self.ui.description_plainTextEdit.toPlainText()

        print("Название:", name)
        print("Степень прожарки:", roast_level)
        print("Тип кофе:", coffee_type)
        print("Цена:", price)
        print("Объем:", volume)
        print("Описание:", description)

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MyMainWindow()
    window.show()
    sys.exit(app.exec())
